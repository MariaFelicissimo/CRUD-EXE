import axios from 'axios';
const api = axios.create({
 baseURL: 'http://localhost:3001'
});
export const getLivro = () => api.get('/Livro');
export const getLivroById = (id: string) => api.get(`/Livro/${id}`);
export const createLivro = (Livro: any) => api.post('/Livro', Livro);
export const updateLivro = (id: string, Livro: any) => api.put(`/Livro/${id}`, Livro);
export const deleteLivro = (id: string) => api.delete(`/Livro/${id}`);
