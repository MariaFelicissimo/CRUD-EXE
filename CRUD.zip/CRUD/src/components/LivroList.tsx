import { useEffect, useState } from 'react';
import { getLivro, deleteLivro } from '../services/App';
import { Link } from 'react-router-dom';
interface Livro {
    id: string;
    name: string;
    description: string;
    price: number;
    quantity: number;
}
function LivroList() {
    const [Livro, setLivro] = useState<Livro[]>([]);
    useEffect(() => {
    loadLivro();
    }, []);
    const loadLivro = async () => {
        const response = await getLivro();
        setLivro(response.data);
        };
        const handleDelete = async (id: string) => {
            await deleteLivro(id);
            loadLivro();
        };
return (
    <div>
 <h1>Livros List</h1>
 <Link to="/add">Add Livro</Link>
 <ul>
 {Livro.map((Livro) => (
 <li key={Livro.id}>
 {Livro.name} - ${Livro.price} - {Livro.quantity} units
 <Link to={`/edit/${Livro.id}`}>Edit</Link>
 <button onClick={() => handleDelete(Livro.id)}>Delete</button>
 </li>
 ))}
 </ul>
 </div>
 );
}
export default LivroList;