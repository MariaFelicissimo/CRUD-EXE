import { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { createLivro, getLivroById, updateLivro } from '../services/App';
interface Livro {
    name: string;
    description: string;
    price: number;
    quantity: number;
}
function LivroForm() {
    const { id } = useParams<{ id: string }>();
    const navigate = useNavigate();
    const [Livro, setLivro] = useState<Livro>({
    name: '',
    description: '',
    price: 0,
    quantity: 0,
    });
    useEffect(() => {
        if (id) {
        loadLivro();
        }
        }, [id]);
    const loadLivro = async () => {
            try {
            const response = await getLivroById(id as string);
            setLivro(response.data);
        } catch (error) {
            console.error("Error loading Livro data", error);
            }
            };
    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
                setLivro({
                ...Livro,
                [e.target.name]: e.target.value,
                });
                };
    const handleSubmit = async (e: React.FormEvent) => {
                    e.preventDefault();
                    try {
                    if (id) {
                        await updateLivro(id, Livro);
                    } else {
                        await createLivro(Livro);
                        }
                        navigate('/');
                    } catch (error) {
                    console.error("Error saving Livro", error);
                    }
                    };
return (
    <form onSubmit={handleSubmit}>
      <div>
      <label>Name</label>
        <input
          type="text"
          name="name"
          value={Livro.name}
          onChange={handleChange}
          />
          </div>
        <div>
         <label>Description</label>
            <input
              type="text"
              name="description"
              value={Livro.description}
              onChange={handleChange}
              />
              </div>
              <div>  
              <label>Price</label>
                <input
                type="number"
                name="price"
                value={Livro.price}
                onChange={handleChange}
                />       
                </div>
                <div>
                <label>Quantity</label>
                <input
                type="number"
                name="quantity"
                value={Livro.quantity}
                onChange={handleChange}
                />
                </div>
                <button type="submit">Save</button>
                </form>
                );
                }
export default LivroForm;
