import LivroList from '../components/LivroList';

function Home() {
    return (
    <div>
    <h1>Livros Management</h1>
    <LivroList/>
    </div>
     );
    }
    export default Home;