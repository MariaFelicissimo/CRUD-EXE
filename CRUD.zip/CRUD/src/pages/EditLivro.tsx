import LivroForm from '../components/LivroForm';
function EditLivro() {
    return (
    <div>
        <h1>Edit Livro</h1>
 <LivroForm />
 </div>
 );
}
export default EditLivro;